from dotenv import load_dotenv
from langchain_google_genai import ChatGoogleGenerativeAI
import streamlit as st

from prompts import STUDY_PROMPT

# Load API key from .env
load_dotenv()

# Gemini model
llm = ChatGoogleGenerativeAI(
    model="gemini-2.5-flash-lite",
    temperature=0,
)

# Chain
chain = STUDY_PROMPT | llm

# ---------------- Streamlit UI ----------------

st.set_page_config(page_title="Smart Study Buddy", page_icon="📚")

st.title("📚 Smart Study Buddy")
st.write("Generate complete study material using Google Gemini.")

topic = st.text_input(
    "Enter Topic",
    placeholder="Example: Machine Learning",
)

difficulty = st.selectbox(
    "Select Difficulty",
    ["Easy", "Medium", "Hard"],
)

generate = st.button("Generate Study Material")

# ---------------- Generate ----------------

if generate:
    if not topic.strip():
        st.warning("⚠️ Please enter a topic.")
    else:
        try:
            with st.spinner("Generating Study Material..."):
                response = chain.invoke(
                    {"topic": topic, "difficulty": difficulty}
                )

            st.success("✅ Study Material Generated Successfully!")
            st.markdown("---")
            st.markdown(response.content)

        except Exception as e:
            st.error(f"Something went wrong: {e}")
