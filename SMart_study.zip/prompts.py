from langchain_core.prompts import ChatPromptTemplate

STUDY_PROMPT = ChatPromptTemplate.from_template("""
You are an expert teacher.

Topic: {topic}

Difficulty Level: {difficulty}

Generate the following study material:

## 📖 Explanation
Explain the topic according to the selected difficulty.

## 💡 Simple Example
Give one simple example.

## 🌍 Real-Life Example
Give one real-life example.

## ❓ 5 MCQs
Generate exactly 5 MCQs with:
- Question
- A, B, C, D options
- Correct Answer

## 🎤 5 Interview Questions
Generate 5 interview questions.

## 📝 Summary
Summarize the topic in bullet points.

Return everything in proper Markdown.
""")
